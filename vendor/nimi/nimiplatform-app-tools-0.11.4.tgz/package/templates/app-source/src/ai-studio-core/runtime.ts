import {
  runRuntimeAIConsumeCapability,
  runRuntimeImageGenerate,
  runRuntimeMusicGenerate,
  runRuntimeMusicTranscribe,
  observeRuntimeMusicTranscription,
  runRuntimeAudioSeparation,
  observeRuntimeAudioSeparation,
  runRuntimeVoiceConvert,
  observeRuntimeVoiceConversion,
  observeRuntimeMusicGeneration,
  runRuntimeSpeechSynthesize,
  runRuntimeSpeechTranscribe,
  runRuntimeVideoGenerate,
  runRuntimeVoiceCatalog,
  runtimeScenarioJobNonSuccessReasonFromError,
} from '@nimiplatform/kit/features/generation/runtime';
import {
  createNimiLocalAppRuntimeScenarioJobClient,
  type NimiLocalAppClient,
} from '@nimiplatform/sdk/app';
import type {
  StudioAudioSeparation,
  StudioCapabilityRunInput,
  StudioCapabilityRunResult,
  StudioManagedArtifact,
  StudioMusicGeneration,
  StudioMusicTranscription,
  StudioNonSuccess,
  StudioNonSuccessDiagnostics,
  StudioNonSuccessReason,
  StudioRuntimeCapabilityDescriptor,
  StudioRuntimeInspection,
  StudioVoiceConversion,
} from './runtime-types.js';
import {
  dispatchStudioCapabilityRuntime,
  type StudioCapabilityRuntimeHandlers,
} from './runtime-dispatcher.js';

// @nimi-authority: rule.nimi.platform.app-ecosystem.p-scaf-019c

export type StudioRuntimeRunnerSet = {
  readonly aiConsume: typeof runRuntimeAIConsumeCapability;
  readonly imageGenerate: typeof runRuntimeImageGenerate;
  readonly musicGenerate: typeof runRuntimeMusicGenerate;
  readonly musicTranscribe: typeof runRuntimeMusicTranscribe;
  readonly musicTranscriptionObserve: typeof observeRuntimeMusicTranscription;
  readonly voiceConvert: typeof runRuntimeVoiceConvert;
  readonly voiceConversionObserve: typeof observeRuntimeVoiceConversion;
  readonly audioSeparate: typeof runRuntimeAudioSeparation;
  readonly audioSeparationObserve: typeof observeRuntimeAudioSeparation;
  readonly musicObserve: typeof observeRuntimeMusicGeneration;
  readonly videoGenerate: typeof runRuntimeVideoGenerate;
  readonly speechSynthesize: typeof runRuntimeSpeechSynthesize;
  readonly speechTranscribe: typeof runRuntimeSpeechTranscribe;
  readonly voiceCatalog: typeof runRuntimeVoiceCatalog;
};

export type StudioCapabilityNonSuccessFactory = (
  capability: StudioRuntimeCapabilityDescriptor,
  reason: StudioNonSuccessReason,
  message: string,
  diagnostics?: StudioNonSuccessDiagnostics,
) => StudioNonSuccess;

export type StudioRuntimeHost = {
  readonly appId: string;
  readonly surfaceId: string;
  readonly abortReason: string;
  readonly translate: (key: string, values?: Readonly<Record<string, unknown>>) => string;
  readonly client: NimiLocalAppClient;
  readonly createScenarioJobClient: typeof createNimiLocalAppRuntimeScenarioJobClient;
  readonly runners: StudioRuntimeRunnerSet;
  readonly nonSuccess: StudioCapabilityNonSuccessFactory;
};

export type StudioCapabilityRuntimeContext = {
  readonly musicSourceAudio?: StudioManagedArtifact;
  readonly voiceSourceVocal?: StudioManagedArtifact;
  readonly voiceTargetAudio?: StudioManagedArtifact;
  readonly separationSourceAudio?: StudioManagedArtifact;
  readonly capability: StudioRuntimeCapabilityDescriptor;
  readonly input: StudioCapabilityRunInput;
  readonly prompt: string;
  readonly scenarioId: string;
  readonly host: StudioRuntimeHost;
};

export type StudioCapabilityRuntimeOrchestrator = {
  readonly appId: string;
  readonly surfaceId: string;
  readonly abortReason: string;
  readonly translate: StudioRuntimeHost['translate'];
  readonly handlers: StudioCapabilityRuntimeHandlers;
  readonly resolveCapability: (capabilityId: string) => StudioRuntimeCapabilityDescriptor;
  readonly inspectRuntime: () => Promise<StudioRuntimeInspection>;
  readonly getClient: () => NimiLocalAppClient;
  readonly createScenarioId: (capability: StudioRuntimeCapabilityDescriptor) => string;
  readonly createScenarioJobClient?: typeof createNimiLocalAppRuntimeScenarioJobClient;
  readonly runners?: Partial<StudioRuntimeRunnerSet>;
  readonly nonSuccess: StudioCapabilityNonSuccessFactory;
  readonly onMissingHandler?: (
    context: StudioCapabilityRuntimeContext,
  ) => StudioCapabilityRunResult | null | Promise<StudioCapabilityRunResult | null>;
};

export const DEFAULT_STUDIO_RUNTIME_RUNNERS: StudioRuntimeRunnerSet = Object.freeze({
  aiConsume: runRuntimeAIConsumeCapability,
  imageGenerate: runRuntimeImageGenerate,
  musicGenerate: runRuntimeMusicGenerate,
  musicTranscribe: runRuntimeMusicTranscribe,
  musicTranscriptionObserve: observeRuntimeMusicTranscription,
  voiceConvert: runRuntimeVoiceConvert,
  voiceConversionObserve: observeRuntimeVoiceConversion,
  audioSeparate: runRuntimeAudioSeparation,
  audioSeparationObserve: observeRuntimeAudioSeparation,
  musicObserve: observeRuntimeMusicGeneration,
  videoGenerate: runRuntimeVideoGenerate,
  speechSynthesize: runRuntimeSpeechSynthesize,
  speechTranscribe: runRuntimeSpeechTranscribe,
  voiceCatalog: runRuntimeVoiceCatalog,
});

export function createStudioRuntimeRunnerSet(
  overrides: Partial<StudioRuntimeRunnerSet> = {},
): StudioRuntimeRunnerSet {
  return { ...DEFAULT_STUDIO_RUNTIME_RUNNERS, ...overrides };
}

export async function runStudioCapability(
  input: StudioCapabilityRunInput,
  orchestrator: StudioCapabilityRuntimeOrchestrator,
): Promise<StudioCapabilityRunResult> {
  const capability = orchestrator.resolveCapability(input.capabilityId);
  const runtime = await orchestrator.inspectRuntime();
  if (runtime.status !== 'connected') {
    return orchestrator.nonSuccess(capability, 'runtime-unavailable', runtime.detail);
  }

  const context: StudioCapabilityRuntimeContext = {
    capability,
    input,
    prompt: input.prompt.trim(),
    scenarioId: input.scenarioId?.trim() || orchestrator.createScenarioId(capability),
    host: {
      appId: orchestrator.appId,
      surfaceId: orchestrator.surfaceId,
      abortReason: orchestrator.abortReason,
      translate: orchestrator.translate,
      client: orchestrator.getClient(),
      createScenarioJobClient: orchestrator.createScenarioJobClient
        ?? createNimiLocalAppRuntimeScenarioJobClient,
      runners: createStudioRuntimeRunnerSet(orchestrator.runners),
      nonSuccess: orchestrator.nonSuccess,
    },
  };

  try {
    const dispatched = dispatchStudioCapabilityRuntime(orchestrator.handlers, context);
    if (dispatched) return await dispatched;
    if (!context.prompt) {
      return orchestrator.nonSuccess(
        capability,
        'input-invalid',
        `${capability.label} requires non-empty input.`,
      );
    }
    const hostProjection = orchestrator.onMissingHandler
      ? await orchestrator.onMissingHandler(context)
      : null;
    if (hostProjection) return hostProjection;
    return orchestrator.nonSuccess(
      capability,
      'sdk-method-unavailable',
      `No Runtime handler is registered for ${capability.id}.`,
    );
  } catch (error) {
    return projectStudioRuntimeError(context, error);
  }
}

export function createStudioScenarioJobClient(context: StudioCapabilityRuntimeContext) {
  return context.host.createScenarioJobClient(context.host.client.ai);
}

type ArtifactRunnerResult = Awaited<ReturnType<
  | typeof runRuntimeImageGenerate
  | typeof runRuntimeMusicGenerate
  | typeof runRuntimeMusicTranscribe
  | typeof runRuntimeAudioSeparation
  | typeof runRuntimeVoiceConvert
  | typeof runRuntimeVideoGenerate
  | typeof runRuntimeSpeechSynthesize
>>;

export async function projectStudioArtifactRunnerResult(
  context: StudioCapabilityRuntimeContext,
  result: ArtifactRunnerResult,
): Promise<StudioCapabilityRunResult> {
  if (result.ok === false) return projectStudioRunnerNonSuccess(context, result);
  if (result.output.kind === 'music-transcription-artifacts' && !context.musicSourceAudio) throw new Error('Music transcription omitted the saved canonical input.');
  if (result.output.kind === 'voice-conversion-artifacts' && !context.voiceSourceVocal) throw new Error('Voice conversion omitted the saved canonical source.');
  if (result.output.kind === 'audio-separation' && !context.separationSourceAudio) throw new Error('Audio separation omitted the saved canonical source.');
  const artifacts: StudioManagedArtifact[] = [];
  const adoptedPaths: string[] = [];
  try {
    for (const [index, sourceArtifact] of result.output.artifacts.entries()) {
      if (!sourceArtifact.artifactId) {
        throw new Error('Runtime artifact metadata omitted the custody artifact identifier required for adoption.');
      }
      const relativePath = await managedStudioAssetPath(
        context.capability.id,
        result.output.jobId,
        index,
      );
      let adopted: Awaited<ReturnType<NimiLocalAppClient['storage']['assets']['stat']>> | undefined;
      const expectedHash = (result.output.kind === 'music-artifacts' || result.output.kind === 'music-transcription-artifacts' || result.output.kind === 'voice-conversion-artifacts' || result.output.kind === 'audio-separation') && 'sha256' in sourceArtifact && typeof sourceArtifact.sha256 === 'string'
        ? `sha256:${sourceArtifact.sha256.replace(/^sha256:/u, '')}` : undefined;
      if ((result.output.kind === 'music-artifacts' || result.output.kind === 'music-transcription-artifacts' || result.output.kind === 'voice-conversion-artifacts' || result.output.kind === 'audio-separation') && (!expectedHash || !/^sha256:[0-9a-f]{64}$/u.test(expectedHash))) throw new Error('Music artifact omitted its content digest.');
      if (expectedHash) {
        // Runtime owns the adopted extension. Each music artifact has its own
        // deterministic directory, so recovery uses returned metadata instead.
        const prefix = relativePath.slice(0, relativePath.lastIndexOf('/') + 1);
        const retained = await context.host.client.storage.assets.list({ prefix, pageSize: 2 });
        if (retained.nextCursor || retained.assets.length > 1) throw new Error('Retained music asset directory is ambiguous.');
        adopted = retained.assets[0];
        if (adopted && !adopted.relativePath.startsWith(`${prefix}result.`)) throw new Error('Retained music asset has an unexpected path.');
        if (adopted && (adopted.sha256 !== expectedHash || adopted.sizeBytes !== sourceArtifact.sizeBytes || adopted.mediaType !== sourceArtifact.mimeType)) throw new Error('Retained music asset does not match the original Runtime artifact.');
      }
      if (!adopted) {
        adopted = await context.host.client.storage.assets.adoptArtifact({ artifactId: sourceArtifact.artifactId, relativePath, overwrite: false });
        adoptedPaths.push(adopted.relativePath);
      }
      if (expectedHash && (adopted.sha256 !== expectedHash || adopted.sizeBytes !== sourceArtifact.sizeBytes || adopted.mediaType !== sourceArtifact.mimeType)) throw new Error('Adopted music asset does not match the original Runtime artifact.');
      artifacts.push({
        relativePath: adopted.relativePath,
        ...(adopted.mediaType ? { mediaType: adopted.mediaType } : {}),
        sizeBytes: adopted.sizeBytes,
        sha256: adopted.sha256,
        displayName: index === 0
          ? context.capability.label
          : `${context.capability.label} ${index + 1}`,
        previewSource: 'managed-asset',
      });
    }
  } catch (error) {
    const cleanupFailures: string[] = [];
    for (const relativePath of [...adoptedPaths].reverse()) {
      try {
        await context.host.client.storage.assets.remove(relativePath);
      } catch (cleanupError) {
        cleanupFailures.push(`${relativePath}: ${studioRuntimeErrorMessage(cleanupError)}`);
      }
    }
    if (cleanupFailures.length > 0) {
      throw new Error(`${studioRuntimeErrorMessage(error)} Managed artifact cleanup also failed: ${cleanupFailures.join('; ')}`);
    }
    throw error;
  }
  let musicGeneration: StudioMusicGeneration | undefined;
  let musicTranscription: StudioMusicTranscription | undefined;
  let voiceConversion: StudioVoiceConversion | undefined;
  let audioSeparation: StudioAudioSeparation | undefined;
  if (result.output.kind === 'music-transcription-artifacts') {
    if (!context.musicSourceAudio) throw new Error('Music transcription omitted the saved canonical input.');
    const pathFor = (id: string) => {
      const index = result.output.artifacts.findIndex(artifact => artifact.artifactId === id);
      if (index < 0 || !artifacts[index]) throw new Error('Transcription result references an unadopted output.');
      return artifacts[index]!.relativePath;
    };
    const value = result.output.transcription;
    musicTranscription = { sourceAudio: context.musicSourceAudio, sourceInfo: value.sourceInfo, inputRange: value.inputRange,
      completeness: value.completeness, origin: value.origin, scores: value.scores.map(score => ({ relativePath: pathFor(score.artifactId), format: score.format, part: score.part })),
      ...(value.timelineArtifactId ? { timelineRelativePath: pathFor(value.timelineArtifactId) } : {}) };
  }
  if (result.output.kind === 'voice-conversion-artifacts') {
    if (!context.voiceSourceVocal) throw new Error('Voice conversion omitted the saved canonical source.');
    const value = result.output.conversion;
    const index = result.output.artifacts.findIndex(artifact => artifact.artifactId === value.vocalArtifactId);
    const vocal = index < 0 ? undefined : artifacts[index];
    if (!vocal || vocal.mediaType !== 'audio/wav') throw new Error('Voice conversion result references an unadopted vocal.');
    voiceConversion = { sourceVocal: context.voiceSourceVocal,
      ...(context.voiceTargetAudio ? { targetVoice: context.voiceTargetAudio } : {}),
      vocal, sourceInfo: value.sourceInfo, inputRange: value.inputRange, vocalInfo: value.vocalInfo,
      lengthRelation: value.lengthRelation, durationDeltaMs: value.durationDeltaMs };
  }
  if (result.output.kind === 'audio-separation') {
    if (!context.separationSourceAudio) throw new Error('Audio separation omitted the saved canonical source.');
    const value = result.output.separation;
    const stemFor = (id: string) => {
      const index = result.output.artifacts.findIndex(artifact => artifact.artifactId === id);
      const stem = index < 0 ? undefined : artifacts[index];
      if (!stem || stem.mediaType !== 'audio/wav') throw new Error('Audio separation result references an unadopted stem.');
      return stem;
    };
    const vocals = stemFor(value.vocalsArtifactId);
    const background = stemFor(value.backgroundArtifactId);
    audioSeparation = { sourceAudio: context.separationSourceAudio, vocals, background,
      ...(value.instrumentParts?.length ? { instrumentParts: value.instrumentParts.map(part => ({ kind: part.kind, artifact: stemFor(part.artifactId) })) } : {}) };
  }
  if (result.output.kind === 'music-artifacts') {
    const generation = result.output.generation;
    const pathFor = (artifactId: string) => {
      const index = result.output.artifacts.findIndex((artifact) => artifact.artifactId === artifactId);
      const path = artifacts[index]?.relativePath;
      if (!path) throw new Error('Music result is missing its adopted artifact.');
      return path;
    };
    musicGeneration = {
      mixRelativePath: pathFor(generation.mixArtifactId), termination: generation.termination, audioInfo: generation.audioInfo,
      ...(generation.actualSeed !== undefined ? { actualSeed: generation.actualSeed } : {}),
      ...(generation.generatedScore ? { generatedScore: { relativePath: pathFor(generation.generatedScore.artifactId),
        format: generation.generatedScore.format, origin: generation.generatedScore.origin, truncated: generation.generatedScore.truncated } } : {}),
    };
  }
  return {
    ok: true,
    capabilityId: context.capability.id,
    capabilityLabel: context.capability.label,
    message: result.message,
    output: {
      kind: 'artifacts',
      ...(musicGeneration ? { musicGeneration } : {}),
      ...(musicTranscription ? { musicTranscription } : {}),
      ...(voiceConversion ? { voiceConversion } : {}),
      ...(audioSeparation ? { audioSeparation } : {}),
      jobId: result.output.jobId,
      jobState: result.output.jobStatus,
      artifactCount: result.output.artifactCount,
      artifacts,
      ...(artifacts[0] ? { firstArtifact: artifacts[0] } : {}),
    },
    ...(result.trace?.traceId ? { trace: { traceId: result.trace.traceId } } : {}),
  };
}

export function projectStudioRunnerNonSuccess(
  context: StudioCapabilityRuntimeContext,
  result: { readonly ok: false; readonly reason: string; readonly message: string; readonly error?: unknown },
): StudioNonSuccess {
  return context.host.nonSuccess(
    context.capability,
    studioNonSuccessReason(result.reason),
    result.message,
    studioNonSuccessDiagnostics(result.error),
  );
}

export function projectStudioRuntimeError(
  context: StudioCapabilityRuntimeContext,
  error: unknown,
): StudioNonSuccess {
  const diagnostics = studioNonSuccessDiagnostics(error);
  const reasonCode = diagnostics?.reasonCode.replaceAll('-', '_').toUpperCase();
  // An input the configured implementation cannot encode completely is an
  // input outcome too; it is never retried or presented as a call failure.
  // @nimi-authority: rule.nimi.runtime.ai-provider.r126
  const reason = reasonCode === 'AI_INPUT_INVALID' || reasonCode === 'AI_INPUT_LIMIT_EXCEEDED'
    ? 'input-invalid'
    : studioNonSuccessReason(runtimeScenarioJobNonSuccessReasonFromError(error));
  return context.host.nonSuccess(
    context.capability,
    reason,
    studioRuntimeErrorMessage(error),
    diagnostics,
  );
}

export function studioNonSuccessReason(reason: string): StudioNonSuccessReason {
  if (reason === 'input-invalid' || reason === 'sdk-method-unavailable'
    || reason === 'principal-unauthorized' || reason === 'operation-aborted'
    || reason === 'runtime-canceled' || reason === 'runtime-timeout'
    || reason === 'stream-interrupted') {
    return reason;
  }
  return 'runtime-call-failed';
}

export function studioNonSuccessDiagnostics(error: unknown): StudioNonSuccessDiagnostics | undefined {
  if (!error || typeof error !== 'object' || Array.isArray(error)) return undefined;
  const record = error as Record<string, unknown>;
  const rawReasonCode = typeof record.reasonCode === 'string' ? record.reasonCode.trim() : '';
  if (!/^(?:[A-Z][A-Z0-9_]{0,127}|[a-z][a-z0-9-]{0,127})$/u.test(rawReasonCode)) return undefined;
  const reasonCode = rawReasonCode.replaceAll('-', '_').toUpperCase();
  const rawActionHint = typeof record.actionHint === 'string' ? record.actionHint.trim() : '';
  const actionHint = /^[A-Za-z0-9_.-]{1,256}$/u.test(rawActionHint) ? rawActionHint : '';
  const rawTraceId = typeof record.traceId === 'string' ? record.traceId.trim() : '';
  const traceId = /^[A-Za-z0-9_.:-]{1,512}$/u.test(rawTraceId) ? rawTraceId : '';
  const source = record.source === 'runtime' || record.source === 'sdk' || record.source === 'realm'
    ? record.source
    : '';
  return {
    reasonCode,
    ...(actionHint ? { actionHint } : {}),
    ...(traceId ? { traceId } : {}),
    ...(typeof record.retryable === 'boolean' ? { retryable: record.retryable } : {}),
    ...(source ? { source } : {}),
  };
}

export function studioRuntimeErrorMessage(error: unknown): string {
  const record = error && typeof error === 'object' ? error as Record<string, unknown> : null;
  const message = error instanceof Error ? error.message.trim() : '';
  const reasonCode = typeof record?.reasonCode === 'string' ? record.reasonCode.trim() : '';
  if (message && reasonCode) return `${message} (${reasonCode})`;
  return message || reasonCode || String(error || 'The Runtime capability call failed.');
}

export function studioAbortError(): Error {
  const error = new Error('Aborted');
  error.name = 'AbortError';
  return error;
}

async function managedStudioAssetPath(
  capabilityId: string,
  jobId: string,
  artifactIndex: number,
): Promise<string> {
  const identity = artifactIndex === 0 ? jobId : `${jobId}:${artifactIndex}`;
  const bytes = new TextEncoder().encode(identity);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  const token = Array.from(digest, (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `media/${capabilityId.replaceAll('.', '-')}/${token}${['music.generate', 'music.transcribe', 'audio.voice.convert', 'audio.separate'].includes(capabilityId) ? '/result' : ''}.asset`;
}
