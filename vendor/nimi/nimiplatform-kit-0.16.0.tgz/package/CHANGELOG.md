# Changelog

## Shared Agent introduction (next minor, development)

- Add `agents.getIntroduction({ agentHandle })` under `agent.local` for every
  covered App, including Home. Rebuild Runtime, SDK, Kit and native carriers
  together; custom standard-shell implementations must supply this method.
- The result contains optional display facts and safe static media, without
  source identity. Source detail is not an App-side substitute for this call.
- Kit exports the shared introduction reader, display mapping and component.
  Home and Zhiyu now use the same projection; no Conversation is opened or
  generated to read the introduction.

## 0.16.0 — Integration and independent Agent work (development)

- Preserve Runtime's existing `AI_CONNECTOR_NOT_FOUND` as `ai-connector-not-found`
  through the native, Electron and Tauri carriers. A stale App AIConfig remains
  a recoverable configuration error and does not invalidate its protected session.
  Rebuild the matching native package when taking this correction.

- The complete protected shell adds `agentWork` and `integration`; custom shell
  implementations must carry their exact typed methods. Retired Conversation
  work fields and tool-result commands are removed, with no compatibility path.
  Upgrade SDK 0.19, Runtime and native npm 0.16 / Rust 0.8 together.
- Integration call carriers preserve `targetDisplayName` and `accountLabel`
  captured by Runtime at admission, including when the connection is later
  removed. These required projection strings may be empty for older facts.
- Known Integration connection failures retain their bounded owner reason in
  `details.reasonMetadata.integration_reason` for Home's localized action
  hints. Transport classification and retry semantics stay unchanged; unknown
  reasons and raw provider messages are not forwarded.
- Electron `bridge.services` adds `agentWork`, `integration`, `activity` and
  `realm.worldCore` for App-owned Node work. Use the existing
  `onSessionInvalidated` hook to stop queues and timers; successful routine
  renewal preserves the same scope. Old in-flight results cannot become success
  in a replacement scope. Provider calls are bounded polls and single results,
  and the App retains its object validation and workflow state.
- Chat can show independent bounded App Activity cards matched only through the
  new `activityAgentRef`. The display correlation never grants Agent access.
- Verified Desktop main-process controls project current execution availability
  and an opaque scope comparison reference. The reference is Host-private and
  must never enter an App client, renderer or Activity record.
- Normal renewal extends the same live scope. Real invalidation fences all old
  business work before empty Host-private `RebindLocalAppSession`; reads and
  writes during rebind fail instead of queuing into the new scope. Old reads
  never transparently receive another account's data. Only the technical status
  probe may finish across rebind; new services explicitly read after readiness.
- Node modules receive fresh clients in `onSessionReady(services)`. Captured old
  `bridge.services` objects are permanently retired on invalidation; bind new
  modules or load new state in the callback without resuming old tasks. Routine
  renewal does not replace clients or invoke the callback.

## Unreleased (0.15.3)

- `CanonicalTranscriptView` no longer keeps the 24px copy gap above
  `emptyStateContent` when every empty-state copy prop is blank. Hosts that draw
  their own heading, such as a character hero, could overflow a viewport-sized
  empty state by that unused gap and show a scrollbar with nothing to scroll.
  Visual change only; the public API is unchanged.
- Change the shared `nimi-accent` pack from cyan `#45B8D6` (hover `#35A7C4`)
  with dark `#111827` primary action text to blue `#1476D4` (hover `#1166B8`)
  with white text, keeping primary action text at or above 4.5:1. The active,
  hover, field-focus and focus-ring tints and the auth brand surface follow the
  new hue. `Steps` status dots now use `--nimi-text-inverse` on status fills so
  they stay legible in both schemes. Visual change only; the public API is
  unchanged.
- `Button` `loading` now rotates its spinner, which previously rendered as a
  static ring, and keeps full color instead of the disabled fade, so work in
  progress no longer reads as an unavailable action. The button stays
  non-interactive with `aria-busy`; under reduced motion the spinner stops and
  the label carries the state. The public API is unchanged.
- Gate calls while a protected session rebind is in progress, reject old in-flight
  responses, and coalesce invalidation before any fresh scope is used. The existing
  `onSessionInvalidated` hook remains the App lifecycle boundary; successful
  routine renewal does not invalidate App state. No SDK/proto/API change.
- App Tools 0.11.3 wires that hook to destroy old renderer windows and create fresh
  ones in the same supervised Host. Consumers with Node business work must also
  cancel their own queues, retries and callbacks in the existing hook. Native
  companion package metadata follows 0.15.3; its native code and ABI are unchanged.

## Unreleased (0.15.2)

- Keep observing the Runtime activity-open stream while Desktop launches the
  source App. Source confirmation or the Runtime deadline can now finish the
  operation even if the launch acknowledgement remains pending; a launch result
  alone still never proves the source object opened. No API change.

## Unreleased (0.15.1)

- Preserve `agent-turn-not-active` through Electron Host error validation so
  consumers can refresh the completed work without retrying an unfenced stop.

## Unreleased (0.15.0)

- Add optional `conversation.interruptTurn({ expectedTurnId })`. Runtime atomically
  refuses `AGENT_TURN_NOT_ACTIVE` when that turn is no longer active, preserving
  any newer work from another App. Work-item stop controls should pass their
  recorded turn ID and refresh the snapshot on rejection. Omitting the field
  retains explicit current-Conversation interruption. Upgrade SDK 0.18, Kit and
  matching native 0.15 together before using the field.

## Unreleased (0.14.1)

- Preserve canonical `role: app` messages in the Electron native Host's snapshot
  and event validation. Apps sharing an Agent can read its Conversation after
  another App's routine commits. Native reference validation also rejects a
  session handle where an `agentBinding` is required. Use matching 0.14.1 native.

## Unreleased (0.14.0)

- Breaking (0.x minor): carry App-scoped `agentBinding`, typed LocalAgent work
  context, pending skill calls and result submission through the standard
  renderer, Electron and native carriers. Upgrade SDK to 0.17 and native to
  0.14 together; custom carrier test fixtures must use four reference fields
  and both new Conversation methods. App calls remain bound to their exact
  initiating session, Agent, anchor and turn. No provider or identity escapes.
- Agent Center bounded context status recognizes the Runtime `app_work` lane.

## Unreleased (0.13.0)

- Carry the synchronous `text-decide` Scenario and per-call control through the
  standard shell (minor). The renderer `ai.scenario.execute(spec, options)` accepts
  `{ signal, timeoutMs }`; the carrier spec keeps text-decide JSON as the SDK's
  canonical `JSON.stringify` text and results are validated against the submitted
  questions. The Electron command admits exactly `{ spec, callId?, timeoutMs? }` and
  `{ action: 'cancel', callId }`; the Host keeps in-flight calls per sender, generates
  the native call identity itself, cancels and releases it through the new
  `localAppScenarioExecuteCancel` and `localAppScenarioExecuteRelease` native
  bindings, and cancels every outstanding call on session invalidation.
  `NimiElectronLocalAppHost.scenarioExecute(input, options)` and
  `bridge.services.ai.scenario.execute(spec, options)` pass the caller signal. A
  caller deadline surfaces as the typed `timeout` reason without dropping the
  protected session; `canceled` and `timeout` join the `scenarioExecute` negative
  states and `ai-input-limit-exceeded` is admitted. Requires the matching native
  package.

- Add validated Runtime/Realm operation selectors and cancellation metadata to
  Electron `commandPolicy` inputs. Hosts can retain setup and repair commands
  while ordinary work is unavailable, without inspecting credentials or request
  bodies. Existing policies remain compatible.

- Breaking (0.x minor): add `configureNimiElectronAppHostProfile` and
  `NIMI_APP_HOST_PROFILE_ENVIRONMENT_KEY`, published on the new
  `@nimiplatform/kit/shell/electron/host-profile` subpath (also re-exported from
  `@nimiplatform/kit/shell/electron/main`). A standard Electron App main imports
  it from the subpath, which loads nothing else from Kit, calls it synchronously
  first, and loads the rest of Kit afterwards (for example with
  `await import('@nimiplatform/kit/shell/electron/main')`), before any session,
  window or `whenReady` work; a Kit module that failed to load before the call
  would otherwise leave Electron on its default paths. It binds `userData`,
  `sessionData` and `temp` to the Host technical profile Nimi Desktop prepared
  under the selected data root and throws when launched without that
  projection. The protected native carrier now prepares that profile for every
  development and installed launch, injects the development `--user-data-dir`
  itself (a caller-supplied one is rejected) and returns `hostProfileRoot` from
  the local-development `launch` result. Migration: rebuild or update an App to
  adopt the new shell; packages built from earlier templates are not patched
  and keep Electron's default profile. Browser-persistent state (cookies, Local
  Storage, IndexedDB) from an earlier default profile does not carry over into
  the new profile.

- Add `runRuntimeVoiceConvert` and `observeRuntimeVoiceConversion` to the
  generation runtime surface for the protected `audio.voice.convert` scenario
  (spec discriminant `audio-voice-convert`). Submissions carry a source vocal,
  a distinct target voice carrier and an optional semitone shift; results
  project the typed conversion with its length relation and duration delta.
  Compatible new export (minor).

- Add `runRuntimeAudioSeparation` and `observeRuntimeAudioSeparation` to the
  generation runtime surface for the protected `audio.separate` scenario.
  Submission takes exactly one inline bytes/URI source or owned artifact source
  with an optional frame range, plus optional instrument stems; results project
  typed vocals, background and instrument-part artifact identities. Compatible
  new export (minor).

- Close protected asset streams even when the consumer returns before reading
  its first chunk or while a read is pending. Asset bodies have one consumer;
  repeated return closes the native resource once. Use the matching SDK fix.

- Add `@nimiplatform/kit/core/audio` for bounded canonical float32 WAV inspection,
  frame reads, waveform blocks, same-domain mixing and streamed export. One block
  is at most 16,384 frames and a mix has at most eight tracks. The injected reader
  must pin protected asset identity; the App owns placement, gains and atomic
  storage. `createPcmWorkerClient` owns a dedicated caller-created Worker and
  transfers input sample buffers. Cancellation terminates that Worker; create a
  fresh client for later work. This is part of the unpublished 0.12 minor cohort.

- AIConfig resource projections may carry `musicInput.generation` profiles for
  exact legal input combinations and bounds. Missing profiles mean unknown or
  inapplicable; Apps must not infer them from model labels. Submission remains
  authoritative, including combined context limits.

- Breaking (0.x minor): music generation now returns a typed `musicGeneration`
  with the mix reference, measured canonical PCM facts, seed when known,
  optional generated ABC score and explicit termination. Consumers must adopt
  the complete artifact set and distinguish a budget cutoff from a natural end.
  The old prior-audio extension is rejected. Use typed score, score conditioning,
  audio reference, seed and instrumental inputs; exact Drivers reject unsupported
  combinations. The common duration ceiling is 600 seconds, with stricter model
  limits retained. Inline ABC imports are at most 1 MiB and expire after 24 hours.
  Update Runtime, SDK, Kit and the native carrier as one cohort.

- Carry an optional music `clientSubmissionId` through protected Job submit
  and its mutually exclusive read-only Get selector. Requires the matching
  SDK and rebuilt native package. Carry Runtime-owned `recoveryExpiresAt` for
  terminal music Jobs and `expiresAt` for canonical imports, with the typed
  temporary-capacity failure. These reuse existing operations and never
  automatically resubmit an author's work.

- Carry canonical audio preparation and owned audio source references through
  the renderer, Electron, Node native and protected Runtime projections.
  Preserve measured frame counts and large-output metadata without expanding
  inline audio or exposing host paths. Shared SDK validators retain carrier
  error ownership. This minor API widening requires the matching SDK/Runtime
  and a rebuilt native package; it is not an engine or App acceptance claim.

- Tooltip: a closed bubble can no longer stay on screen. If the exit
  animation never reports completion, the presence boundary is remounted
  after `TOOLTIP_EXIT_WATCHDOG_MS` and the stale bubble is dropped. The
  Radix root is now always controlled so re-hovering a trigger while its
  previous bubble is still animating out reopens the tooltip instead of
  being cancelled by Radix's own "tooltip.open" listener. Compatible
  behavior fix (patch); the public `Tooltip` props are unchanged. The new
  `TOOLTIP_EXIT_WATCHDOG_MS` constant is an additive public export (minor).

- Breaking (0.x minor): the local-app standard shell adds the App activity
  namespace and seven `nimi.shell.localApp.activity*` commands, carried by the
  Electron host, the Desktop formal host, the protected-local Node-API binding
  (native packages 0.12.0) and the Tauri shell (`nimi-shell-tauri` and
  `nimi-shell-protected-local` 0.7.0). Pair Kit 0.12.0 with SDK 0.16.0 and
  upgrade renderer, host glue and native carrier together.
- Activity open is Host-mediated: the consumer Host receives the Runtime-issued
  open request, asks the running Desktop to launch or focus the exact source
  over the Desktop Open transport (`requestElectronAppActivitySourceLaunch`),
  and returns only the Runtime result to renderer code. Renderer commands can
  pull only their own activity subscriptions; the open request id never reaches
  renderer code. When the launch or focus fails, the Host still reports a
  running source's confirmation that arrives within
  `NIMI_APP_ACTIVITY_LAUNCH_FAILURE_GRACE_MS` (5 s). A renderer pull that waits
  for the next change stays outside a Host's exclusive data-root operation gate.
- `createNimiElectronLocalAppHostForBinding` accepts an optional activity launch
  function as its third argument, and the standard shell host accepts
  `appActivitySourceLaunch` for Desktop's in-process launch owner.
- Local-development activity source opening focuses the exact supervised
  running Host through the private `focusHost` control and matching native
  `desktopFocusLocalDevelopmentHost` binding; update native and Host packages
  together. Cold starts continue through the existing launch owner.
- After a session rebind, the Electron and Desktop formal hosts replay only
  activity listing. Publication, read marks, change subscriptions and open
  deliveries fail with the session reason instead of reaching the next session
  or account; consumers re-list or re-subscribe explicitly.
- The Electron local-app Host checks the session status before each routine
  rotation, so a session the Runtime already invalidated (for example after an
  account change) reaches `onSessionInvalidated` before renewal installs a fresh
  session.

- CanonicalComposer accepts optional `sendLabel` and `copy` props and forwards
  them to the inner ChatComposer, so hosts can localize the send button's
  accessible label and composer copy through the canonical surface. Compatible
  public input widening (minor); existing callers are unchanged.

- Breaking (0.x minor): retire the archived Simulator-only `scrollLock:
  'simulator-root'` overlay option. Active renderer hosts use `scrollLock:
  'none'`; Simulator integrations are archived rather than migrated.

- Model Config sections accept `collapsible: false` for a static heading with
  always-visible rows, and the surface accepts `showTitle: false` when the
  host chrome already labels the surface. Both are compatible optional
  presentation inputs (minor type widening); editing and mutation scope are unchanged.

- Model Config accepts optional host-owned capability sections with localized
  headings and collapsible groups through `ModelConfigCapabilitySection` and
  `capabilitySections`. This compatible public input widening is a minor
  change; existing ungrouped surfaces and AIConfig mutation scope are unchanged.

- Restyled the built-in current-machine Local action in Model Config as a
  titled quick-setup card with an explicit description, and clarified its
  Kit-owned base English and Chinese title, label, and hint copy. Action
  semantics, the state catalog, and mutation scope are unchanged.
- Breaking (0.x minor): custom `ModelConfigCurrentMachineLocalActionCopy`
  objects must now include `title` for the quick-setup card heading. Hosts
  using the built-in English or Chinese copy need no changes.

- Breaking: `OauthListenForCodePayload` now requires `expectedState`. Pass the
  Runtime-issued attempt state (or the state of the specific social OAuth
  attempt) with `redirectUri`. Upgrade renderer and Electron/Tauri host glue
  together. Missing, unrelated or incomplete callbacks no longer consume the
  listener. Runtime retains final authorization and code-exchange ownership.
- Callback pages report receipt of authorization, not completed account login.
- Electron OAuth callback completion no longer waits for unrelated active HTTP
  connections to close. POST bodies are limited to 16 KiB and 10 seconds;
  responses have a bounded one-second flush window before socket cleanup.

## 0.11.0 (development)

- Read the current Local resource through formal options when switching from
  Cloud. The picker and draft show that Local resource; saving still commits
  only route intent and never changes the machine's Loadout selection.

- Carry optional typed `referenceAudioInput` on AIConfig Local resources and
  Cloud targets through the native and renderer boundaries. It reports exact
  byte/URI support, reference-text mode and MIME types without exposing
  credentials, content or an execution override. Missing metadata is unknown.
- Use SDK 0.15.0 with native 0.11.0 and the matching Runtime for this field.
  App code should read these conditions instead of testing model names.
  No AIConfig storage migration or new App permission is introduced.

## 0.10.1 (development)

- Preserve and validate the Runtime-issued `spaceId` in renderer Local App
  embedding results. The public SDK contract already requires this identity;
  the renderer no longer rejects a valid result as an unknown field. Keep
  rejecting missing, invalid, or privileged result fields. SDK 0.14.0 and
  native 0.10.0 remain compatible; no Runtime protocol change is required.

## 0.10.0 (development)

- Derive installed App custom-protocol origins using Electron's exact scheme
  and host, consistently with other shell renderers. Keep exact renderer URL
  checks and reject opaque `null` and foreign origins.

- Finish Node business-service asset reads and subscriptions at Host EOF without
  closing the retired handle again. Successful audio retrieval and completed
  text streams no longer fail with a spurious `not-found`; explicit cancellation
  still closes active resources.

- Apply declared inline-audio byte limits independently of decimal JSON
  expansion in the renderer bridge. Preserve multiline transcription content
  and empty pending/no-speech text while retaining content and metadata bounds.

- Preserve annotation results up to 65536 tokens and 16 MiB through the native
  and JavaScript boundaries with the matching SDK/Runtime candidate.

- Carry `text-annotate` through native, Electron and renderer Job services.
  Preserve completed-job `textAnnotation`, including exact source whitespace
  and Unicode scalar offsets. Use the matching SDK 0.14.0 development candidate.

- Carry Local `audio-separate` requests and complete vocals/background artifact
  pairs through native, Electron and renderer services. App-specific media
  assembly and final project commits remain with the App.

- Preserve typed speech transcription through protected native, Electron and
  renderer job results, and expose it in `runtimeSpeechTranscribe` results.
  The projection carries original text, detected language, actual word/character
  timing and explicit no-speech status. Requires SDK 0.14.0, native packages
  0.10.0, Rust shell crates 0.6.0 and the matching Runtime.
- Custom carriers must retain optional completed-job `transcription` data and
  validate it consistently with `transcriptionText`. Consumers requiring word
  alignment must request it from an eligible resource; text-only output is not
  a timing fallback. No-speech results can have empty text.
- Local development packages precede publication; real consumer acceptance
  remains required before release.

## 0.9.0

- Abort uncommitted renderer asset writes and close reads on document replacement,
  renderer loss and bridge shutdown. Routine native session renewal no longer waits
  for an upload body to finish before revalidating the same live context.
- Preserve native plain-JSON Cloud model targets in Local App AIConfig options
  and committed snapshots, so model selection does not attempt a second
  Protobuf Struct conversion.
- Preserve nonempty whitespace text deltas. Malformed AI stream projections
  report a renderer result error and cancel the subscription, rather than
  blaming a valid caller request.
- Relay bounded opaque reasoning-continuity events through the renderer in
  their original order, so Codex tool turns retain their required continuity.
- Carry ordered user image URL and owned image Artifact parts through the
  existing Local App text-turn and text-generate operations. Requires SDK
  0.13.0, Rust shell crates 0.5.0 and the matching Runtime. Custom native
  bindings must preserve optional message `parts`; the text-candidate surface
  remains unchanged. Provider/model selection and artifact ownership stay
  Runtime-owned.

All notable changes to `@nimiplatform/kit` are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
The project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)
with the pre-1.0 discipline documented in `kit/AGENTS.md` §Semver
Discipline.

## [Unreleased]

### Local App text tools (0.8.0)

- Requires SDK 0.12.0, the matching 0.8.0 native binding, and a Runtime that
  admits the extended Local App text contract. Function tools, ordered tool
  results and structured response formats use the existing text stream and
  scenario execute operations. App-owned Node work can use `bridge.services`
  on the same protected Host and cancel on `onSessionInvalidated`.
- Migration: handle the `tool-call` stream event and `tool-calls` finish reason;
  text deltas now include `itemIndex`. Scenario execute adds `text-generate`.
  Update exhaustive event/output matches. Rust shell crates advance to 0.4.0;
  rich turns use `LocalAppTextMessage` and the extended text request fields.
  The narrow text-candidate operation keeps its existing input contract.
- These APIs represent one model step. The App owns its tool handlers and
  subsequent steps; the model binding does not execute callbacks or resume
  interrupted work.
- The same unreleased minor adds `reasoning-continuity` stream/output items.
  Preserve their ordered opaque carrier in later assistant turns without
  displaying it. The common SDK model uses `Uint8Array`; the native JSON
  carrier uses byte arrays, bounded to 64 KiB per payload. Raw reasoning and
  reasoning controls are not exposed by Local App consumption.

### World creator interface (next minor)

- Preserve canonical dynamic world content consistently across list, create,
  get and replace, while keeping transport identity fields closed. Native world
  calls preserve Realm content-conflict, rate-limited and unavailable reasons.
- Align Tauri artifact uploads with the public image, WAV, MP3 and MP4 MIME set.
- Add protected `realm.worldCore` creation eligibility, world detail/replacement,
  world-character list/detail/create/replacement, world-entity list/detail/create,
  and world-relationship list/detail calls across Electron, native and Tauri.
  Realm enforces account-specific administrator authorization for world creation;
  `realm.data`, subscription and role do not grant that business permission.
- Migration: the exact Local App shell method set expands. Upgrade SDK, Kit,
  native carrier and Runtime together before using these methods. Custom shell
  implementations must implement the complete typed surface and preserve typed
  failures. These source changes are unreleased; existing public package versions
  do not provide them. No direct Realm transport or compatibility fallback is added.

### Added

- The protected music runner accepts an optional `durationSeconds` generation
  budget (1–180 whole seconds), forwarded by the typed SDK and Electron carrier.
  This is a compatible public input widening (minor release); it requires the
  matching Runtime contract and is not an exact-duration or audio-extension claim.

### Fixed

- Preserve icon decorations and loading feedback when `Button asChild` uses a
  link or custom element, and accept the canonical Realm Realtime envelope at
  the Electron native carrier boundary while rejecting unknown envelope fields.

- Accept `audio/x-wav` Runtime artifacts under the same RIFF/WAVE validation as
  `audio/wav`, keep Agent Realtime sessions open after successful individual
  turns, and share overlapping development inventory reads without retaining
  completed snapshots. These fixes are also backported to the 0.5.1 stable line.

### Added

- ProgressIndicator accepts an unknown value and places accessible names and
  value descriptions on the actual progressbar. This compatible input widening
  belongs to the 0.7.0 minor surface; existing numeric values still work.
- Kit/native 0.7.0 and the 0.3.0 Rust shell crates carry the protected App
  download pause, resume and reorder methods with Runtime-owned queue and
  progress projections. Hosts with exhaustive native method or App job phase
  matches must handle the new variants. Kit 0.7.0 requires SDK 0.11.0.

- Added typed image and finite-video face replacement Jobs and four bounded
  video Session commands to the unreleased minor surface. Custom protected
  bindings must implement `localAppVideoSessionOpen`, `localAppVideoSessionSubmit`,
  `localAppVideoSessionRead`, and `localAppVideoSessionClose`; frames cross the
  carrier as base64 while the public SDK accepts and returns `Uint8Array`.
  Artifact upload now admits `video/mp4`. SDK consumers replace the removed
  `NimiLocalAppArtifactImageMime` type with `NimiLocalAppArtifactUploadMime`.
- Added the macOS arm64 native package and main-only installed App control to
  the 0.6.0 component release. The shared installed-launch transaction uses a
  macOS current-user, same-session suspended child and retains its real exit
  status and process group. Runtime still owns package and App Access admission;
  Developer ID absence is not replaced with Nimi signing or a development path.
  Public macOS catalog lifecycle acceptance remains a separate product gate.
- Added an optional main-only `desktopHost.runtimeLifecycle` port so Home's
  service registration/approval policy also handles renderer lifecycle calls.
  This compatible host-input widening belongs to the unreleased minor surface;
  it does not expose a new renderer command or change App access.
- Added main-only verified installed App launch, focus, stop and Runtime session
  Access projection. Windows launch checks exact lease bytes, current-user
  non-elevated tokens and an owner-scoped Job Object before resuming the child.
  Kit/native 0.6.0 adds host error variants for direct process failures; hosts
  with exhaustive error matches must handle them. Renderer SDK profiles expose
  neither the launch lease nor executable paths or process identifiers.
- Added verified uninstall reservation to the Desktop machine-product facade.
  Desktop main stops the exact Host before Runtime atomically unregisters and
  removes its managed package; interrupted detachment is restored at startup.
- Added protected Desktop machine-product Catalog listing and verified package
  install methods, with exact public Registry policy reason/revision forwarding.
  This public method-set widening belongs to Kit 0.6.0; hosts with exhaustive
  native method matches must handle the two new variants. Installed launch and
  App Access remain separate owner operations.
- Added the public Windows x64 D2 native dependency and packaged Electron D2
  binding resolution. Installed Apps use their own native payload and retain
  Runtime peer, registration, exact Desktop launch, and App Access checks;
  Catalog/install/launch availability remains a separate product cutover.
- Added the optional `emptyStateAgent` identity and `emptyStateContent` slot to
  the chat `CanonicalTranscriptView` empty state, so a host can render the
  agent avatar/name and centered content (such as a composer) in place of the
  eyebrow overline. An explicitly empty `emptyTitle` now suppresses the empty
  heading instead of rendering an empty element.
- Added the optional `trailingIcon` slot to `NimiMenuItem` for trailing
  affordances such as a selected-state check icon.

### Changed

- Lowered the chat `ConversationComposerShell` surface elevation from
  `floating` to `raised`.

## [0.3.0] - 2026-08-31

### Added

- Added the optional Electron main-process `runDataRootOperation` host seam so
  a product Host can serialize fixed standard storage/artifact operations with
  an explicit Product Control data-root replacement handoff. The seam carries
  no path, owner registry, or renderer authority.
- Added the bundled Avatar asset-host `detachDataRoot` lifecycle seam, which
  drops admitted handles without deleting former-root temporary bytes during
  Product Control replacement; ordinary final host shutdown still cleans the
  current session root.

### Removed

- **Breaking (0.x):** Removed the public NAS-era
  `EmbodimentProjectionApi`, `ActivityFallbackOptions`,
  `AvatarActivityFallbackBundle`, and projection-smoothing exports, including
  the optional `runDefaultActivity` fallback contract. Built-in activity and
  signal projection are now Avatar-owned implementation details; consumers
  must use admitted backend primitives without a compatibility alias.
- **Breaking (0.x):** Removed `semantics.nas_fallback` from the public
  `Live2DAdapterManifestV1` contract. Live2D adapters now contain only the
  built-in Avatar semantic mappings; manifests retaining the retired field are
  rejected by the closed v1 parser and must delete it without a compatibility
  alias.
- **Breaking (0.x):** Removed the optional `AgentCenterVoiceAssetsClient` and
  `voiceAssetsClient` factory input. Agent Center now discovers bounded
  current-session-owned custom VoiceAsset choices through the canonical
  `agentConfigure.sharedAIConfig.listOptions({ kind: 'voice-assets' })`
  operation, so Desktop, protected Apps, production, and Simulator use the
  same Manager client. Consumers must remove the extra client injection;
  VoiceAsset create and delete remain separate `runtime.consume` operations.
- **Breaking (0.x):** Removed the unreachable Agent Center appearance shadows
  `linkLive2dAdapterManifest`, `clearAvatarAsset`, `clearBackground`,
  `removeAgentResources`, and `cleanupGeneratedVoiceArtifacts`, together with
  their pending/error-only projection fields. The canonical covered-App
  factory never implemented these methods. Consumers must use the admitted
  `replaceAvatar`, `importBackground`, `setDefaultVoice`,
  `setAvatarAutoplay`, and `restorePreviousAppearance` flows; no compatibility
  forwarding remains.
- **Breaking (0.x):** Removed `createFirstPartyAgentCenterSession`, its
  raw-identity input contract, and the shell-owned Agent Center presentation
  transport. All eligible consumers now use
  `createAppAgentCenterSession({ handle, client, hostMechanics })`; Host
  mechanics may select or temporarily hold native material but the canonical
  App client owns every product read and commit.
- **Breaking (0.x):** Removed the deprecated `ConversationShell`,
  `ConversationModeSwitcher`, `ConversationSidebarShell`, `ConversationThreadList`, and
  `ConversationTranscriptShell` public exports. Consumers must use the canonical chat surfaces.
  `Statistic` also removes the deprecated `brand` tone alias; use `primary`.
- **Breaking (0.x):** Removed the publicly reachable test-only helpers
  `resetSharedAudioPipelineControllerForTesting`,
  `resetSharedVoiceLipsyncStateBusForTesting`, and
  `clearAgentCenterRegisteredDialogPathsForTest`. Package consumers must not mutate
  Kit singleton or dialog-registration state; tests should construct and own their
  local controller, state-bus, or bridge lifecycle instead.
- **Breaking (0.x):** Removed the `features/commerce` gift dialog, inbox,
  and Realm adapter exports after the Realm and Nimi gift product hard cut.
  Consumers must remove gift affordances; no replacement or compatibility
  alias is provided.
- **Breaking (0.x):** Removed Kit Realm Chat realtime event/session/ack/replay, socket-controller, token-resolution, and persistent outbox exports. Generated Realm HTTP chat, sync-window, timeline, and Runtime-local Agent conversation surfaces remain. The message projection/cache helpers now use neutral `normalizeRealmMessageView`, `mergeRealmMessageIntoMessagesResult`, `applyRealmMessageToChatsResult`, `applyRealmMessageUpdateToMessagesResult`, and `applyRealmMessageUpdateToChatsResult` names; callers must move to those exact exports. Backend realtime protocol ownership must stay app/Runtime-owned until exact Runtime authority admits a shared implementation; no compatibility facade or offline replay replacement is provided.

### Added

- **Breaking (0.x):** `NimiLocalAppStandardShell` and the canonical formal App
  client add the required `embodiment.snapshot` and `embodiment.subscribe`
  namespace for every App with matching `agent.local` coverage. Host adapters
  must carry the two exact protected operations and preserve their ordered
  uint64 cursor; consumers receive only Runtime-owned activity, emotion,
  semantic posture, provenance, and bounded voice-timing correlation. Do not
  migrate renderer motion, lipsync, audio clock, replay, backend probe, or
  diagnostic fields into this namespace; there is no optional or privileged
  compatibility client.
- **Breaking (0.x):** The protected Local App Conversation surface adds the
  canonical `conversation.renderVoice` operation. Consumers request final
  voice only with the current opaque Agent handle, Conversation anchor,
  committed assistant message id, and idempotency request id, then read ready
  audio through `conversation.readArtifact`; raw Agent identity, caller text,
  voice selection, and first-party Runtime turns are no longer valid inputs.
- **Breaking (0.x):** Agent Center's canonical App factory now requires the
  bounded `agentConfigure.manager.snapshot` operation and exposes explicit
  `invalidate()` / `dispose()` session lifecycle. Host integrations must build
  the Manager from the current opaque `agentHandle`, invalidate it before an
  account, session, Conversation, or Agent switch, and inject file selection,
  temporary custody, and native preview only through the non-authoritative Host
  mechanics seam. Raw Agent identity and first-party product transports are not
  valid replacements for the canonical Manager client. Shell hosts should pass
  `createAgentCenterShellBridge()` through
  `createAgentCenterShellHostMechanics()`; avatar/background selection no
  longer accepts account or Agent scope and returns bounded material for the
  canonical session to commit.
- `ConversationSetupPanel` accepts optional `eyebrow` and `diagnosticsLabel`
  props so hosts can render product-toned setup copy, and raw issue codes now
  render inside a collapsed diagnostics disclosure instead of a prominent
  engineering block. `CanonicalConversationShell` forwards the new optional
  `setupEyebrow`, `setupTitle`, `setupActionLabel`, and `setupDiagnosticsLabel`
  props to the panel. All additions are optional and backward compatible.
- The protected Local App standard shell now exposes the canonical typed neutral
  AI Realtime and Agent Realtime channel operations, including bounded audio
  frames, owner control, subscriptions, status, output interruption, and close.
  All formal Apps use the same SDK contract; provider protocol and protected
  carrier state remain host-private.
- `ConfirmDialog` accepts a `loading` prop for the async submission state. The
  confirm button now forwards it to the shared Button `loading` behavior,
  rendering a spinner with `aria-busy` and disabled semantics. While submission
  is active, cancel, backdrop, and Escape dismissal are disabled as well, so an
  unavailable cancellation is not presented as an interactive action.
- The protected Local App standard shell and `@nimiplatform/sdk/app` expose the
  exact owner-scoped PersonaCharacter `listOwned`, `getOwned`, `create`, and
  `replace` operations with Runtime owner mediation, closed safe DTOs, typed
  sanitized failures, and no generic Realm or credential surface.
- Generation runners expose the bounded text/chat sampling set, batch text
  embeddings, video artifact references, and speech synthesis timing mode while
  preserving explicit optional scalar zero values on Runtime requests.
- The protected Local App standard shell exposes Runtime-selected foreground
  text candidate generation through the public renderer bridge.
- The Local App AI surface now includes bounded text-turn streaming, synchronous
  scenarios, Scenario Jobs, artifact reads, and voice-asset listing. Kit also
  re-exports the SDK Local App Scenario Job adapter so existing generation
  runners can consume the protected carrier without a Runtime proxy.
- Model Config can open an explicitly requested capability detail on first
  mount, allowing capability-specific host entry points to reuse the shared hub.
  Third-party App hosts expose only a read-only projection plus a handoff to the
  exact Nimi-owned App configuration surface, without receiving Local/Cloud,
  implementation, provider-model, or Connector authoring
  controls. The protected Local App carrier now supplies the
  bounded current Local-selection display projection used by Model Config while
  withholding configuration identity, bindings, LocalAssets, paths, and
  execution truth.
- Model Config local-selection projections now include bounded, read-only
  Driver-owned effective request defaults. Empty fields can explain the active
  on-device engine default without writing that value into App or Agent
  AIConfig intent.
- The shared `DatePicker` and `DatePickerPanel` accept an optional `labels`
  prop (a `Partial<DatePickerLabels>`) that overrides panel and field copy.
  Omitted keys keep the built-in Chinese defaults, so existing consumers
  render unchanged.
- `NumberStepper` accepts optional `decreaseLabel` / `increaseLabel` props
  and `NimiToaster` an optional `dismissLabel` prop, so hosts can localize
  the step-button and toast close-button accessible names. Defaults keep the
  previous English copy. The `AccountPanel` action button now falls back to
  the `actionLabel` text instead of a hardcoded `Edit` when no `actionIcon`
  is given. All three are non-breaking minor additions; existing consumers
  render unchanged.
- Chat surfaces accept an optional `copy` prop (`ChatCopy`, resolved by
  `resolveChatCopy` against `DEFAULT_CHAT_COPY`) covering the previously
  hardcoded English strings across the canonical target pane, character
  rail, stage panel, message bubble, stream status, markdown renderer,
  composer, and thread list. `CanonicalConversationShell` now forwards that
  copy through its built-in target, character, stage, and transcript surfaces,
  including typing announcements/actions, relationship states, and Markdown
  code-copy controls. `RealmChatTimeline` and `AppAiChatPanel` accept `emptyStateLabel`, and
  `CanonicalTranscriptView` accepts `emptyActionLabel`. Defaults keep the
  previous English copy.
- Avatar surfaces accept an optional `labels` prop
  (`AvatarPhaseLabelOverrides`) for viewport/stage phase copy, with
  `resolveAvatarPhaseLabel`, `DEFAULT_AVATAR_PHASE_LABELS`, and the
  `AvatarPhaseLabels` types exported from `avatar/ui`, `avatar/vrm`, and
  `avatar/live2d`. Missing or failed media now falls back to a shared
  placeholder surface. Lazy VRM/Live2D viewports are guarded by an error
  boundary with an explicit failure state, retry action, localized failure
  labels, and an optional host error callback instead of silently replacing a
  renderer failure with an ordinary placeholder. Failure controls use a compact
  layout in small and medium circular stages so retry remains visible and
  operable inside the clipped frame.
- Generation panels accept optional `dismissErrorLabel` and `getStatusLabel`
  props so hosts can localize the error-dismiss accessible name and the
  status vocabulary instead of rendering raw English enum values. Submitted
  and queued statuses now receive their semantic info/warning tones.
- Agent Center locale catalogs add `AgentCenter.appearance.revisionLabel`,
  `voiceKindPreset`, `voiceKindAsset`, and the loading-state announcement in
  both English and Chinese.
- `LoadingSkeleton` accepts a localized `label`; when supplied it exposes a
  polite status announcement, while unlabeled decorative skeletons remain
  hidden from assistive technology.
- Kit primitives complete the API vocabulary convergence: `TypographyRole`
  gains `'overline'`; `Toggle`, `DatePicker`, and `SidebarSearch` accept
  `onValueChange`; `OverlayShell` and `DialogContent` accept a
  `'data-testid'` prop; `OverlayShellSize` and `DatePickerSize` accept
  lowercase canonical members (`'sm'|'md'|'lg'|'xl'` and `'sm'|'md'`);
  `Statistic` and `Timeline` tones accept `'primary'`.

### Changed

- **Breaking (0.x):** protected Local App conversations now use ordered
  content parts, Runtime-issued message identities, durable image-action and
  final-voice projections, and the purpose-bound attachment upload/read and
  voice-transcription operations. The former text-only send, event, and
  snapshot members are removed. Migration: construct `parts` on send, reduce
  the closed message/action/voice event union, and hydrate from the new
  conversation snapshot; do not retain a parallel text-only reader.
- **Breaking (0.x):** Agent Center capability rows now come from the Runtime
  participation projection instead of a Kit-owned capability denominator.
  Migration: pass the shared LocalAgent AIConfig response, including its
  ordered `participation` rows, to the existing Agent Center session/adapter.
- **Breaking (0.x):** Agent Center replaces the removed permission/grant
  session factory with `createAppAgentCenterSession({ handle, client })` for
  every protected App whose current session has `agent.configure` coverage.
  The factory consumes the SDK's single nominal `NimiLocalAppAgentHandle` and
  typed `NimiLocalAppAgentConfigureClient`; removed exports
  include `createPermissionedAgentCenterSession`,
  `sealAgentCenterPermissionedSdkSurface`, permission-posture types, and the
  duplicate Kit Agent-handle brand. There is no compatibility path.
- **Breaking (0.x):** Desktop Open removes the `open-agents` target together
  with `NimiDesktopOpenAgentsIntent` and `NimiDesktopOpenAgentsView`. Character
  and partner catalog entry now uses `open-explore` with `section: 'personas'`
  and the admitted `discover-personas` or `select-partner` product intent; the
  retired target is rejected rather than aliased or redirected.
- `Tooltip` keeps enabled interactive children as the sole focus target and
  supplies a single keyboard-focusable disabled-action wrapper when the native
  control cannot receive hover or focus, preserving access to disabled reasons.
- `ConfirmDialog` deprecates the `pending` prop in favor of `loading`. `pending`
  remains as a compatible alias that maps to the Button `loading` state, so
  existing callers keep working while gaining the spinner and `aria-busy`
  affordances; migrate to `loading` to silence the deprecation.
- **Breaking (0.x):** Async ScenarioJob generation runners now distinguish a
  caller-local `operation-aborted` outcome from Runtime-observed durable
  `runtime-canceled` and `runtime-timeout` terminals instead of collapsing
  them into `runtime-call-failed`. Generation `ok: false` types and helpers now
  use the neutral NonSuccess vocabulary, and custom runners can use the
  exported terminal-status-from-error mapper. `RuntimeExecutionUnavailable`
  remains the exact SDK-method-unavailable projection.
- **Breaking (0.x):** Model Config machine-selection projections and navigation
  callbacks now use exact Machine Loadout vocabulary (`loadoutId` and
  `onOpenMachineLoadout`). The former machine-configuration names were removed
  without compatibility aliases.
- Renderer bridge errors retain structured reason, action, trace, and retry
  fields while scrubbing credentials and private paths from `message`,
  `details`, and `details.rawMessage`.

- **Breaking (0.x):** Kit no longer exports the retired Runtime model-root,
  manifest-picker, or LocalAsset-ID reveal helpers. ModelAsset custody and paths
  are Runtime-owned; hosts must use the protected Runtime ModelAsset flows and
  must not reconstruct managed storage paths.

- **Breaking (0.x):** Model Config no longer exports the retired
  `projectModelConfigLocalSelections`, `ModelConfigMachineAggregateInput`, or
  `ModelConfigMachineConfigurationInput` compatibility projection. Hosts must
  supply the Runtime-owned bounded current Loadout-selection projection
  directly; Kit does not reconstruct it from machine-local configuration and
  selection arrays.

- **Breaking (0.x):** `handleSocialOAuthLogin` now completes only a
  Realm-owned browser session. `OAuthLoginInput.onSuccess` is a payload-free
  completion signal, callers must provide the canonical
  `completeBrowserSessionLogin` current-user refresh, and token-mode or
  unconfirmed responses fail closed. The former bearer callback has no
  compatibility overload or alias.

- **Breaking (0.x):** The mixed `ShellAuthPage` / `DesktopShellAuthPage` and
  `AuthPlatformAdapter` exports are replaced by separate `WebAccountAuthPage`
  with `WebAccountAuthAdapter` from `@nimiplatform/kit/auth`, and
  `DesktopBrowserAuthGate` with
  `DesktopBrowserAuthRuntimeBroker`. Desktop consumers must remove credential
  and token-persistence adapter methods; Web consumers must use the
  Realm-owned browser-session completion projection. No compatibility exports
  are retained.

- **Breaking (0.x):** Renderer-facing OAuth token exchange is removed from the
  standard shell, Kit OAuth bridge, and public token-bearing types. OAuth code
  listeners remain available; exchange and custody must stay in an authorized
  non-renderer owner (Realm/Runtime, or Desktop native host for managed
  connectors).

- **Breaking (0.x):** Realm OAuth login/link helpers and Kit auth adapters now
  accept the canonical provider-specific credential object. Google requires a
  Google Identity Services ID token; TikTok carries its authorization code,
  redirect URI, and PKCE verifier to Realm for server-side exchange. The
  retired access-token signature and Shell-side TikTok exchange are removed.

- **Breaking (0.x):** Twitter OAuth is removed from Kit auth UI, social OAuth
  provider types, account-link surfaces, and Electron token exchange. Consumers
  must remove Twitter login/link actions; no compatibility provider alias is
  retained.

- **Breaking (0.x):** Every covered App may read, CAS-overwrite, and list bounded
  Local/Cloud options for its own canonical AIConfig owner. Desktop remains an
  optional centralized manager rather than a configuration prerequisite.

- Model Config restores the established AI Model hub, capability-detail, Active
  Model trigger, and compact Local/Cloud picker UX. App and Agent Local choices
  now project the machine-selected Loadout and deep-link to the Loadout owner
  AI configuration instead of selecting a machine model. Cloud choice is
  Connector-first for every covered App: the user selects one exact Connector
  and target, then commits both through the same single Save without a separate
  permission or confirmation flow.

- **Breaking (0.x):** `registerNimiElectronAppBridge` no longer accepts
  `onProtectedSessionFailure`. Consumers must keep App and Host lifecycle
  independent from protected-session availability; Kit keeps the bridge
  registered, returns bounded typed unavailable posture, and owns bounded
  same-Host rebind.
- **Breaking (0.x):** The scoped-route Model Config implementation is replaced
  by explicit App AIConfig, shared LocalAgent AIConfig, and first-party Machine
  Local AI owner modes. Public `./features/model-config` and
  `./features/model-picker` root/headless/ui exports are restored with canonical
  intent and non-committing choice contracts. Retired exports remain removed:
  `./core/model-config` and `./features/model-picker/runtime`. Generation
  modality request types no longer
  accept scoped configuration, binding, model, route, or target inputs. Text,
  image, video, synthesis, and transcription requests carry only caller identity,
  scenario content, and supported parameters; Runtime owns implementation
  selection. Owner-scoped voice-asset reference listing remains available.
- **Breaking (0.x):** The Local App carrier replaces per-Agent AI configuration,
  readiness, and AIProfile commands with shared LocalAgent-subsystem AIConfig
  get/overwrite and portable-profile preview/apply. The new operations carry no
  Agent handle, configuration revision, readiness, model binding, or owner
  assertion; autonomy and presentation remain per-Agent.
- **Breaking (0.x):** The generic standard-shell `ai-config.get` /
  `ai-config.set` capability and its Electron/Tauri host-local file stores are
  removed. AIConfig persistence and mutation belong to Runtime-owned canonical
  owner services; no shell-store compatibility path is shipped.
- **Breaking (0.x):** Agent Center now accepts exactly one nominal
  `AgentCenterSession` plus UI-only chrome/layout/density/section/i18n/placement/
  display-identity props. The session owns snapshot refresh, independent
  revisions, all mutations, readiness subscription, and the closed
  product-action availability projection. Removed public exports:
  `createRuntimeAgentCenterAdapter`, `createPermissionedAgentCenterAdapter`,
  `CreateRuntimeAgentCenterAdapterInput`,
  `CreatePermissionedAgentCenterAdapterInput`, `createGrantedAgentCenterPosture`, `createUnavailableAgentCenterPosture`,
  `isAgentCenterPostureGranted`, `agentCenterPostureReasonText`,
  `AgentCenterRuntimeAdapter`, `AgentCenterFirstPartyCarrierAdapter`,
  `AgentCenterPermissionedCarrierAdapter`, `AgentCenterCapabilityGroup`,
  `AgentCenterPermissionPostureState`, `AgentCenterPermissionReasonCode`,
  `AgentCenterPermissionPostureReason`, `AgentCenterCapabilityPosture`,
  `AgentCenterPermissionPosture`,
  `AgentCenterPermissionedPresentationPreviewInput`, and
  `AgentCenterPermissionedPresentationPreview`. Removed `AgentCenter` props:
  `state`, `runtimeAdapter`, `permissionedAdapter`, `runtimeLoadInput`,
  `appearanceAdapter`, `copy`, `appearanceCopy`, `behaviorCopy`, and `ariaLabel`; removed
  `localAgentRef` from `AgentCenterIdentityProjection`. Use
  `createAppAgentCenterSession({ handle, client })` and the canonical
  `i18n` seam. This is a pre-1.0 hard cut with no compatibility path.
- **Breaking (0.x):** Agent Center autonomy writes require their independent
  `expectedRevision` and return through the Manager Session's revised snapshot;
  `autonomyMutationAvailable` and `autonomyDisabledReason` placement inputs are
  removed.
- Agent Center adds one component-level `i18n.t` binding, dynamic canonical capability projection
  including `audio.transcribe`, visible loading and embedded load-error states,
  and cross-section mutation write-back. The unsupported AI Profile import
  affordance is hidden.
- **Breaking (0.x):** Agent Center capability ids are dynamic catalog strings
  rather than a handwritten union, and autonomy/presentation revisions are
  separate from Agent AI Config revision.
- **Breaking (0.x):** Agent Center cognition state replaces
  `recentCanonicalMemories` with the content-free
  `recentCanonicalMemoryCount`; consumers must use memory state/counts rather
  than private canonical Memory summaries, classes, or policy reasons.
- **Breaking (0.x):** Agent Center model state now consumes the dedicated Runtime
  Agent model-settings projection and its decimal CAS revision. The fabricated
  `NimiAIConfig` conversion path, fixed scope constant, and numeric revision
  bridge are removed; hosts inject `AgentCenterModelSettingsModule`.
- **Breaking (0.x):** Agent Center Appearance is now warning → pick → automatic
  Runtime commit. Candidate preview/apply state and public preview resolver
  helpers are removed. Imported bytes cross the Shell boundary in the same
  commit; validation and save failures preserve current appearance, committed
  renderer failure is distinct, and a successful replacement exposes one-step
  restore of the Runtime-projected previous profile.
- Agent Center's Avatar adapter now renders committed-effect evidence only and
  continues to share the Avatar-owned controlled-surface predicate.

- Avatar activity routing and generated-motion contracts are no longer
  duplicated as public Kit exports. Their concrete execution owner remains the
  Avatar app. This is a breaking pre-1.0 API cut.

- Standard Apps registry, package, account-inventory and lifecycle projections
  are removed. The current Kit projects only local-development records and the
  factory AI-profile index; retained Platform catalog metadata cannot activate
  an ordinary App. This is a breaking pre-1.0 API cut.

- Auth shell entry actions now use a host-neutral callback and expose the
  primary semantic marker only while the logo is the actionable entry control;
  the compact logo on later embedded stages is named and behaves as Back.

- `SidebarResizeHandle` now accepts native div interaction attributes instead
  of requiring a mouse-only handler, allowing consumers to use pointer capture
  without document-global drag listeners. This is a breaking pre-1.0 API cut.
- Design authority redesign (P-DESIGN-027 / P-DESIGN-028, spec-owned in
  `.nimi/spec/platform/kernel/**`):
  - Motion: one unified duration/easing scale (`motion.fast` 120ms,
    `motion.base` 200ms, `motion.slow` 320ms, `motion.ambient` 600ms plus
    four easing tokens) shared by CSS and the TypeScript mirrors;
    `motion.fast`/`motion.slow` values changed (160ms/240ms are retired).
  - Motion: new kit motion layer (`@nimiplatform/kit/ui/motion`) built on
    the `motion` package — spring presets, symmetric spring overlay
    grammar, gesture momentum helpers, `NimiMotionProvider`. Overlay
    enter/exit motion moved from (previously dead) CSS keyframe classes
    to spring-driven motion.
  - Interaction: `Button`/`IconButton`/`Toggle`/`SegmentedControl`/
    interactive `Surface` now give immediate pressed feedback
    (`motion.pressed_scale`, 0.97) on pointer-down; hover translate
    lifts are removed; `transition: all` is banned from governed
    components.
  - Shape: standard actions resolve `radius.action` = 12px (capsule
    `radius.full` 999px is reserved for chip/filter/status/pill
    primitives). This is a breaking pre-1.0 visual change.
  - Density: new runtime axis via `NimiThemeProvider density` +
    `data-nimi-density` and the generated `nimi-density-compact.css`
    pack (`sizing.*`/`typography.*` overrides); consumers must import
    `@nimiplatform/kit/ui/themes/nimi-density-compact.css`.
  - Material: glass tiers now compose `backdrop.saturate` (180%)
    vibrancy; material role matrix (canvas / structural chrome /
    content / floating) is contractual.
  - Typography: `NimiText` applies token letter-spacing, CJK profiles
    via `:lang(zh)`, and `font-optical-sizing: auto`; new `hero-title`
    role for expressive boundaries.
  - A11y: focus ring now consumes the real `focus.ring_*` tokens
    (previously it silently fell back to a hardcoded blue).
- Added `kit/preview` — a source-linked workbench for inspecting governed
  UI surfaces in the current development environment.
- Motion coverage follow-through: `SelectField` and `Tooltip`/`TooltipContent`
  moved onto the popover spring grammar with the positioning/animation
  split pattern (Radix popper owns positioning on the outer element,
  motion owns visual enter on the inner element). `ActionMenu` items
  gained pressed feedback. Radix Select Content has no `forceMount`,
  so dismissal unmounts immediately — matching platform menu behavior.
- Density axis: generated density pack selectors now cover both
  `:root[data-nimi-density=...]` (out-specifies scheme selectors) and
  subtree boundaries, and ship the `expressive` escape-hatch reset that
  restores foundation sizing/typography inside compact regions. Desktop
  renderer root defaults to `compact` density.
- Accent migration (brand decision): the `nimi-accent` pack moved from
  mint green `#4ECCA3` to cyan blue `#45B8D6` (hover `#35A7C4`),
  separating the brand accent from `status.success` green. The light
  hero gradient and ambient mesh slot 4 moved to the same hue family,
  `--nimi-accent-onAccent` alias updated, and every app/test hardcoded
  copy of the legacy mint hex was replaced with token references
  (zhiyu fallback vars, desktop home/relationship/world/profile
  surfaces, tester studio chrome, landing mint scale). The desktop
  design-contract gate now forbids both the current and legacy raw
  brand hexes.
- **Breaking (0.x):** `ChatMarkdownRendererProps.appearance` no longer
  accepts `'relay'`. The relay branch referenced app-private token
  classes that Kit does not define and had no production consumer; use
  the default `'canonical'` appearance.
- **Breaking (0.x):** Agent Center removes the no-op `layout` and `density`
  props and their inert data attributes. Consumers should remove both props;
  Agent Center owns one stacked regular-density composition.
- **Breaking (0.x):** Agent Center removes the unused
  `AgentCenterAppearanceCopy` export and 100 orphaned appearance catalog keys
  left behind by the retired diagnostic/setup UI. Consumers should use the
  canonical `AgentCenterI18n` key seam for the remaining appearance surface.
- Chat deprecates the legacy `ConversationShell` family
  (`ConversationShell`, `ConversationSidebarShell`,
  `ConversationStageLayout`, `ConversationTargetRail`,
  `ConversationThreadList`, `ConversationTranscriptShell`,
  `ConversationModeSwitcher`, and their prop types) in favor of the
  canonical conversation shell family; the exports remain functional.
- Agent Center replaces its private control set with shared Kit
  primitives (Button, Toggle, SelectField, ConfirmDialog,
  ProgressIndicator, InlineAlert, StatusBadge), moves its accent from a
  hardcoded emerald palette to the brand action-primary and status
  tokens, adds arrow-key roaming to the section tabs and the behavior
  radiogroup, and gates the appearance live view on the module's own
  committed-readiness predicate.
- Avatar viewport `badgeLabel` resolvers now return the phase id when no
  action cue is present, with copy rendered through
  `resolveAvatarPhaseLabel` at the UI layer; the idle phase label is unified
  to `'Idle'`, and the VRM/Live2D placeholder surfaces share a single
  implementation.
- **Breaking (0.x):** Avatar removes unused `accentColor` and `glowColor`
  fields from the VRM/Live2D viewport-state projections and deletes their
  unrendered hardcoded emotion palette. Consumers should derive any visual
  treatment from admitted theme tokens at the rendering boundary.
- Chat bubble geometry (corner radius, text size, max width) is unified
  across the canonical, realm-timeline, stream-status, and app-AI
  surfaces; message timestamps use a shared 24-hour `formatMessageTime`
  helper; the image preview overlay uses the standard dialog z-layer
  instead of hardcoded `z-[1000]`/`z-[1001]` overrides; composer errors
  render through `InlineAlert`; legacy `bg-mint-*` classes that no theme
  defines are replaced with success status tokens; the settings toggle
  row exposes `role="switch"`/`aria-checked`; and the closed canonical
  drawer/right sidebar are `inert` and close on Escape.
- Model Picker route tabs render through `SegmentedControl` (radio
  semantics), Generation progress through `ProgressIndicator`, and Model
  Config loading through `LoadingSkeleton`. `panelClassName` no longer implies
  the legacy `max-w-sm rounded-3xl` overrides.
- Kit primitive vocabulary deprecations (all aliases remain functional):
  `Toggle.onChange`, `DatePicker.onChange`, and `SidebarSearch.onChange`
  in favor of `onValueChange`; the uppercase `OverlayShellSize` members
  (`'S'|'M'|'L'|'XL'`) and DatePicker `'normal'|'small'` sizes in favor of
  lowercase canonical members; the `Statistic`/`Timeline` tone value
  `'brand'` in favor of `'primary'`; and the `dataTestId` prop in favor of
  `'data-testid'`. `FeedbackTone` is now an alias of `StatusTone`.
- **Breaking (0.x):** Agent Center appearance catalogs drop the unused
  `AgentCenter.appearance.enableLabel` and
  `AgentCenter.appearance.disableLabel` keys together with the matching
  `AgentCenterAppearanceCopy` fields; the autoplay control is now a shared
  Toggle. Hosts referencing those keys must remove them.
- Chat, Agent Center, and Avatar surfaces now render from
  surface/text/status/elevation tokens instead of hardcoded light-palette
  classes, hex fallbacks, and literal shadows, so
  `applyNimiTheme({ scheme: 'dark' })` now reaches those surfaces.
  Hardcoded brand gradients, inline `backdrop-blur` material fills, literal
  durations/easings, and off-scale font sizes/radii in those modules were
  migrated to the corresponding Kit tokens and `Surface` materials in the
  same pass.

### Fixed

- Agent Center now commits shared AIConfig and autonomy state directly from
  the canonical mutation response. An unrelated follow-up projection read can
  no longer turn a successful Runtime write into a reported failure or leave
  the Manager Session on the pre-commit revision.
- Agent Center catalogs cover the current speech-synthesis and image-generation
  capabilities in English and Chinese, and host bindings can report missing
  keys so the shipped Kit fallback is not replaced by a generic `Label`.
- Shared kit primitives now consistently expose the standard token-driven
  focus ring. `Toggle`, `NumberStepper` step buttons, `SidebarItem`,
  `Pagination` page buttons, `DashedAddButton`, `FieldTrigger`, and
  `Breadcrumb` links/buttons gained `FOCUS_RING_CLASS_NAME`, and the
  hand-written simplified rings in `ActionMenu`, `NimiTabs`,
  `SegmentedControl`, `PillTabs`, and `AccountPanel` items/action were
  replaced with the same constant so ring width, color, and offset all come
  from the `--nimi-focus-ring-*` tokens. `Tooltip` and `TooltipTrigger`
  wrapper spans are now keyboard focusable (`tabIndex=0`), so keyboard users
  can open tooltips by focusing the trigger; hover behavior is unchanged.
- `DatePicker` closes on Escape and returns focus to its trigger, its panel
  uses the popover z-layer token instead of `z-[120]`, and its focus ring
  references the valid `--nimi-focus-ring-*` tokens instead of the
  nonexistent `--nimi-ring`.
- Model Config capability-defaults numeric fields no longer swallow decimal
  points or minus signs while typing: intermediate drafts like `0.` or `-`
  stay in the field, only complete valid numbers commit, integer fields
  reject fractional input, and blurring an invalid draft restores the last
  valid value.
- `EmptyState` accepts a ReactNode `title` (the HTML attribute intersection
  no longer narrows it to string); `FieldShell` links its label to the
  wrapped control with `htmlFor`/`id`; `Steps` marks the current step with
  `aria-current="step"`; `DialogContent` restores initial focus into the
  dialog and returns focus on close, matching `OverlayShell`; the Toast
  viewport no longer double-announces items (its duplicate `aria-live` is
  removed); `LoadingSkeleton` is `aria-hidden` instead of announcing an
  empty live region; and `SelectField` warns in development when an option
  with an empty-string value is dropped (a Radix limitation).
- The canonical target pane focus ring references the valid
  `--nimi-focus-ring-color` token instead of the nonexistent `--nimi-ring`.
- `Button` `asChild` now hands the button chrome directly to the single child
  element instead of wrapping it in the native-button icon/spinner spans.
  Those extra wrapper children made Radix Slot (>= 1.2.5) throw
  "Slot failed to slot onto its children" and unmounted every consumer tree
  that rendered `<Button asChild>`. Callers that passed `leadingIcon` /
  `trailingIcon` together with `asChild` should inline the icon into the
  slotted child, matching Radix single-child semantics.

### Changed (pre-existing entries)

- Removed the bearer-bearing `authToken` prop from `RealmChatTimeline`.
  Protected image/video material must now enter through the optional
  `resolveMediaSource` owner adapter, which returns a renderer-safe URL and an
  optional disposer. Kit no longer fetches Realm media with an Authorization
  header. This is a breaking pre-1.0 minor change.
- Hardcut the pre-1.0 Electron local-app carrier to
  `registerNimiElectronAppBridge` and `local-app-standard-shell-v1`. The public
  surface is now exactly session status, reserved public-permission posture,
  and bounded app-private JSON storage. Consumers must replace the retired
  operation/resource grant, Runtime artifact, Agent inventory/conversation,
  voice, and artifact-only host/bootstrap helpers with
  `createNimiLocalAppStandardShellSurface`; no compatibility alias is shipped.
  Kit advances to `0.3.0` for this breaking pre-1.0 minor change.

### Added

- Added `@nimiplatform/kit/shell/renderer/host` as the provider-scoped
  `nimi.renderer.host/v1` surface: exact canonical host bindings, opaque
  instance identity, explicit renderer/overlay targets, per-instance theme,
  host-neutral capability errors, and overlay lease contracts without a
  process-global fallback.
- Added the Agent Center bounded LocalAgent source/context projection. Kit now
  consumes the SDK-validated source status and latest turn summary through its
  core SDK contract, maps them to the closed `ready`, `blocked`, `truncated`,
  `failed`, or `unknown` UI states, and renders read-only Overview/Advanced
  diagnostics without raw context or machine reason copy.
- Added `@nimiplatform/kit/auth/shell` as a lightweight public auth entry
  that exports `ShellAuthPage` and its adapter/type contracts without the
  desktop shell particle background or Three.js dependencies.
- Added Electron host command policy types on `@nimiplatform/kit/shell/electron/main`
  so installed-app hosts can deny selected standard/app-domain commands before
  their handlers run while preserving structured fail-closed shell errors.
- Added `@nimiplatform/kit/features/agent-center` as the reusable Runtime
  Local Agent Center surface. Apps now consume typed Runtime/appearance
  adapters instead of passing arbitrary app panels into Agent Center; model
  readiness, autonomy, cognition, appearance, and advanced diagnostics are
  rendered from Runtime/SDK projections.
- Admitted five standard shell capabilities across `shell/capabilities`,
  `shell/renderer/bridge`, `shell/electron`, and `nimi_shell_tauri`:
  `file-dialog.open`, `file-reveal.reveal`, `export.saveFile`,
  `artifacts.write`, and the `floating-window.*` operation family
  (platform rule `P-KIT-041F`). Hosts without an implementation fail closed
  with `capability-unavailable`; the installed-app capability set forbids all
  of them by default.
- Finalized the `floating-window.*` three-layer contract (renderer bridge,
  Electron host hooks, and the new `nimi_shell_tauri::standard_floating_window`
  Tauri command module). Contract shapes: `setBounds` takes an integer,
  physical-pixel `{x?,y?,width?,height?}` patch (at least one field; `x`/`y`
  and `width`/`height` move together); `beginManualDrag` takes no payload and
  returns `{mode:'manual', originX, originY}` — `mode` is a
  `'system'|'manual'` union reserved for a future platform, but both hosts
  always report `'manual'` (system-level `start_dragging` is unreliable for
  transparent always-on-top windows) plus the window's current outer position
  as the drag origin; `moveManualDrag` takes
  `{originX, originY, totalDeltaX, totalDeltaY}` and sets the window position
  to `origin + totalDelta`; `constrainToVisibleArea` takes `{minVisibleRatio}`
  (clamped `0.05..=1.0`, default `0.2`) and returns `{constrained}` indicating
  whether the window actually moved. The renderer type exports changed from
  `FloatingWindowManualDragPoint` to `FloatingWindowBounds`,
  `FloatingWindowIgnoreCursorEventsOptions`,
  `FloatingWindowManualDragOrigin`, `FloatingWindowMoveDelta`, and
  `FloatingWindowConstrainResult`. Tauri exposes a standalone opt-in handler
  macro `nimi_shell_tauri_floating_window_commands!` (the eight
  `floating_window_*` commands only) that is deliberately excluded from the
  default runtime/auth/oauth handler families so window control is not granted
  to apps that do not opt in.
- Added `createElectronShellFileProtocolHost` (`shell/electron`): kit-owned
  `nimi-shell-file` protocol registration, path/root validation, and the
  readable-file registry for standard local-asset URL serving.
- Added Tauri standard shell-ui host hooks
  (`set_standard_shell_ui_host_hooks`): apps inject confirm-dialog, focus
  target, and window-drag policy instead of registering same-name app-local
  command forks.
- Added renderer-safe text storage helpers to `@nimiplatform/kit/core/storage-json`
  so apps can share browser storage access mechanics without moving schema
  ownership into Kit.
- Exported `emitRendererLog` from `@nimiplatform/kit/telemetry` so renderer
  bridge code can use the shared telemetry normalizer directly.
### Fixed

- Electron Runtime account metadata now pre-registers local first-party and
  developer account callers before account projection lookup, while preserving
  launch-bound installed app caller handling.
- Renderer telemetry now forwards through the installed Nimi shell runtime
  bridge/test hook when available, without importing Tauri bridge code from
  `kit/telemetry`.
- VRM emote blending (`kit/features/avatar` `createVrmEmoteState`) now
  accumulates elapsed time per blend and eases between the weight at blend
  start and the target, so a blend completes in `blendDurationSec` under
  real per-frame deltas. The previous per-frame incremental easing
  (`easeInOutCubic(dt / duration)` applied to the remaining gap) converged
  at roughly 1.7%/s at 60fps (~170s for a 0.4s blend), and its exact-float
  completion check kept finished blends in the update loop forever.

### Changed

- **Breaking (0.x):** Agent Center capability state no longer retains Runtime
  readiness reason codes. Readiness is rendered through closed human copy;
  consumers that displayed `AgentCenterCapabilityState.reasonCode` must use the
  bounded readiness state and their own admitted copy namespace instead.
- **Breaking (0.x):** Agent Center Shell preview resolution now returns
  `previewMaterialRef` only. Consumers must pass that material to an
  Avatar-owned `AgentCenterAvatarPreviewAdapter`. Appearance readiness requires
  the typed ready state, matching material and backend, a controlled preview
  image, and positive visible pixels. Preview artifact, evidence, and checksum
  receipts are no longer part of the public result.
- **Breaking (0.x):** `AgentCenterAppearanceAdapter` no longer exposes
  account-wide `removeAccountResources`. Account teardown must use the
  low-level Shell bridge from an account-scoped orchestrator; per-agent Agent
  Center transactions may only remove their own resources.
- **Breaking (0.x)**: Agent presentation mutation now requires the caller's
  canonical uint64-string `expectedRevision` and returns
  `{ profile, committedRevision }`. Migration: retain and pass the revision
  returned by the preceding read or successful mutation. Kit consumers do not
  retry revision conflicts and must not substitute `"0"` or any other fallback.
- **Breaking (0.x)**: Agent Center shell custody payloads now use strict
  discriminated scope contracts. The nine local-agent operations require
  `hostScope: 'local-agent'` plus non-empty `accountId`, `ownerUserId`,
  `runtimeSourceRef`, and `localAgentRef`; account resource cleanup requires
  `hostScope: 'account'` plus `accountId`. Migration: pass the complete Runtime
  identity scope to every local-agent custody call and an explicit account
  scope to account cleanup. Missing fields no longer reach a host as partial
  payloads and fail closed as `invalid-payload`. Tauri-only `select` and
  `displayName` import inputs and `selected` results are removed; consumers
  must not send renderer-owned selection/display mutations or read local
  selection truth from custody results.
- **Breaking (0.x)**: Electron `standardShellHost` storage root input moved
  from a plain `dataRoot: string` to the Runtime-attested
  `standardDataRootBinding` (`runtime-get-app-storage` resolved lazily by the
  host through Runtime `GetAppStorage`, or `runtime-launch-projection` with
  attested roots plus `projectionRef`). Migration: dev/acceptance hosts pass
  `{ source: 'runtime-get-app-storage' }` (or a projection binding sourced
  from an acceptance fixture root), and the Desktop installed-app host passes
  the Runtime OpenApp launch-projection roots. There is no silent
  `userData` fallback for standard storage resolution. The legacy
  `dataRoot`/`cacheRoot`/`tempRoot` host fields and the app-provided
  `resolveLocalAssetUrl` host hook are fully removed (no transitional
  compatibility): a host missing `standardDataRootBinding` fails closed with
  `electron-standard-data-root-binding-missing`, and local-asset URL serving is
  owned solely by `localAssetProtocolHost` (missing → `capability-unavailable`).
- **Breaking (0.x)**: Tauri standard data/storage commands now read managed
  `StandardAppStorageRootSlot` state resolved from `StandardDataRootBinding`
  (`StandardAppStorageRoot` removed); an unmanaged or unresolved slot fails
  closed with `tauri-standard-storage-binding-missing`. Standard storage
  payloads reject renderer-supplied root fields
  (`path`/`root`/`storageRoot`/`absolutePath`/`dataRoot`/`cacheRoot`/`tempRoot`)
  on both hosts.
- Replaced the shared `DatePicker` popover with a three-column year / month /
  day wheel selector and removed the old monthly calendar-grid panel. This is
  a 0.x interaction break: consumers that relied on `DatePickerPanel`'s old
  `displayMonth` / `onDisplayMonthChange` panel props must update to the new
  wheel-panel contract.

## [0.1.3] - 2026-05-27

### Changed

- Hard-cut archived app-specific shell/auth affordances from the public kit
  surface: `ShellMode` now admits only `desktop` and `web`, and
  `ShellAuthTheme` no longer exposes the archived `relay-dark` palette.

## [0.1.2] - 2026-05-25

### Fixed

- Included nested auth CSS theme assets in the published `dist` package so
  `@nimiplatform/kit/auth/styles.css` resolves every relative `@import`.
- Extended the kit dist package guard to fail when a published CSS file
  references a missing relative CSS asset.

## [0.1.1] - 2026-05-24

### Fixed

- Hardened npm package publishing so public subpath exports resolve to
  compiled `dist` JavaScript and declaration files instead of raw
  `src/**/*.ts` / `src/**/*.tsx` source files.
- Added a dist package guard that fails when package exports point outside
  `dist`, leak source paths, or reference missing build outputs.

## [0.1.0] - 2026-05-23

Initial public publish for the ST-L1-2 standardization work.
`@nimiplatform/kit` becomes the single cross-app toolkit package
for Nimi apps with 58 public subpath exports while remaining in a
pre-1.0 iteration phase.

### Added

- **Public exports inventory** (58 entries): 11 UI entries (`./ui`,
  `./ui/glass`, `./ui/motion`, `./ui/a11y`, `./ui/styles.css`, and six
  `./ui/themes/*` files), 3 auth entries, 6 core entries (including
  `./core/sdk-contract`), 2 renderer-shell entries, 2 telemetry entries,
  and 34 feature entries across `chat`, `avatar`, `model-picker`,
  `model-config`, `generation`, `commerce`.
- **SDK contract boundary admission** at `kit/core/src/sdk-contract.ts`:
  single audit surface for kit-to-SDK coupling. All static
  `@nimiplatform/sdk*` imports inside kit code (non-test) route through
  this file. Re-exports cover 5 admitted S-SURFACE-001 sub-paths
  (`/`, `/runtime`, `/realm`, `/types`, `/mod`).
- **a11y primitives module** (`./ui/a11y`): `FOCUS_RING_CLASS_NAME`
  applied to `Button` and `IconButton` for WCAG 2.1 AA keyboard focus
  visibility, visually hidden helper constants, focus-trap hook.
- **Motion primitives module** (`./ui/motion`): SSR-safe
  `usePrefersReducedMotion` hook and `MOTION_TIMING` tokens. Respects
  `prefers-reduced-motion: reduce`.
- **Glass primitives module** (`./ui/glass`): shared frosted-surface
  primitives extracted from prior duplicated implementations across
  feature modules.
- **Cross-feature edge documentation**: `chat → avatar` and
  `model-config → model-picker` admitted as documented one-way feature
  compositions. Documented at `kit/core/src/sdk-contract.ts` header and
  `kit/AGENTS.md` §Cross-Feature Edges.
- **Counting vocabulary** for SDK-coupling audits at `kit/AGENTS.md`
  §Counting Vocabulary: `importing-file count`, `import-statement count`,
  `export-statement count` kept distinct.
- **Semver discipline doc** at `kit/AGENTS.md` §Semver Discipline:
  pre-1.0 patch/minor/major classification rules, migration-note
  requirements for breaking 0.x minors, and directional alignment with
  `@nimiplatform/sdk`.

### Changed

- **`kit/features/chat/src/runtime/orchestration.ts`**: the dynamic
  SDK import for `getPlatformClient` now routes through
  `@nimiplatform/kit/core/sdk-contract` instead of
  `@nimiplatform/sdk` directly, eliminating the last bypass of the
  single-boundary contract.
- **`kit/README.md`**: rewritten as external-consumer documentation
  covering installation, version policy, import patterns by sub-module,
  theming integration, accessibility, motion, and the SDK contract
  boundary explanation.

### Versioning

This is the initial public publish in the 0.x line. Patch releases are
reserved for compatible fixes. Minor releases may add exports or carry
breaking changes during the pre-1.0 phase, but any breaking 0.x minor
requires a migration note. Alignment with `@nimiplatform/sdk` remains
directional until the SDK reaches 1.0.0, at which point kit must make
an explicit 1.0.0 readiness decision.

### Migration notes

None — initial release. Consumers previously building against
unpublished workspace paths should update to the npm package name
`@nimiplatform/kit` and keep `@nimiplatform/sdk` aligned with the
compatible pre-1.0 range selected by their app.

[0.1.3]: ./
[0.1.2]: ./
[0.1.1]: ./
[0.1.0]: ./
